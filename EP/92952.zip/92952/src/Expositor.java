import java.util.Collection;

public interface Expositor {
	Collection<String> items();
}
