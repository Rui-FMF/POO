package aula01;

public class teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
