package aula08;

public class Ex1 {

	public static void main(String[] args) {
		//Por razaões pessoais não tive oportunidade de acabar o guião prático, falta a classe principal no ex1 mas as restantes classes devem funcionar como pretendido
	}

}
