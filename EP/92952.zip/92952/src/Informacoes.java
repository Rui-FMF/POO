
public class Informacoes {
	private String contacto;

	public Informacoes(String contacto) {
		this.contacto =contacto;
	}

	public String getContacto() {
		return contacto;
	}

}
